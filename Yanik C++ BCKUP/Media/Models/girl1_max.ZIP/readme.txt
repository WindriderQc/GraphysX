texture 512*512
1049 vertices
1079 faces
not triangulate
Use it however you want, credit me if you want but its not essential.

petomavar@yahoo.com



