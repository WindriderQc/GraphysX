Thank you for visiting The 3D Studio and downloading our free models, we hope you enjoy them. Please review the license agreement below.

Matthew S. Anderson
www.the3dstudio.com
info@the3dstudio.com
www.matcoland.com
info@matcoland.com

This model was downloaded from The 3D Studio.

This model was donated to The 3D Studio from the people at Futoro Plano.

They can be contacted at FuturoPlano@graphic-designer.com

Please contact the author for permission to use this model in a commercial setting.

Please visit their web site at http://www.go.to/futuroplano