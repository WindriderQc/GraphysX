-- 3dvia.com   --

The zip file 23seating-model3d.3ds.zip contains the following files :
- readme.txt
- 23seating-model3d.3ds


-- Model information --

Model Name : Women seating
Author : 
Publisher : rtheet

You can view this model here :
http://www.3dvia.com/rtheet/media/610A4557697B4D5F
More models about this author :
http://www.3dvia.com/rtheet


-- Attached license --

A license is attached to the Women seating model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailled license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/licenses/
