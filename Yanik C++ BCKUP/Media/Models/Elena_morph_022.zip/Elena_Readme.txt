Elena custom morph for V3 Sae - Version 0.22 - copyrighted by Mdd - May 2007

This is an original morph created with Blender.

This freebie can be used for personal and commercial projects as long as you don't resell it in whole or in part or 
re-distribute it without prior written consent. 
You cannot claim that this is your own work in any case.

Tested in Daz Studio and Poser 5.

------------------------------------------------------------------------------------------------------------------------
Release history:

0.2  - First release
0.21 - Fixed the eyes morph removal (thx to abcuser from Renderosity)
0.22 - Some minor mesh fix
------------------------------------------------------------------------------------------------------------------------

Zip file content:

Runtime\libraries\Pose\Mdd\Elena_Morph
  
  Elena.png  
  Elena.pz2
  Elena-Remove.png
  Elena-Remove.pz2
  
Runtime\libraries\!Mdd_Morph

  Hide.pElena.pz2
  InjDeltas.pElena.pz2
  RemDeltas.pElena.pz2
  Unhide.pElena.pz2
            
